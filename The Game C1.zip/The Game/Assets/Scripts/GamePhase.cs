﻿public enum GamePhase
{
	Team1Go,
	Team2Go,
	Switch
}
